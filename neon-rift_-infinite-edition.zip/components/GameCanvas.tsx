
import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Player, Obstacle, Particle, GameStatus } from '../types';
import { 
  CANVAS_WIDTH, 
  CANVAS_HEIGHT, 
  GRAVITY, 
  INITIAL_SPEED, 
  SPEED_INCREMENT, 
  MAX_SPEED,
  THEMES
} from '../constants';

interface GameCanvasProps {
  status: GameStatus;
  onGameOver: (score: number) => void;
  onScoreUpdate: (score: number) => void;
  onSpeedUpdate: (speed: number) => void;
  onEvent: (type: 'nearMiss' | 'streak' | 'milestone') => void;
}

const GameCanvas: React.FC<GameCanvasProps> = ({ 
  status, 
  onGameOver, 
  onScoreUpdate,
  onSpeedUpdate,
  onEvent
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number | undefined>(undefined);
  const [currentThemeIndex, setCurrentThemeIndex] = useState(0);

  const playerRef = useRef<Player>({
    x: 150, y: CANVAS_HEIGHT - 60, width: 36, height: 36,
    dy: 0, jumpForce: -14, grounded: false, angle: 0,
    stretchX: 1, stretchY: 1, opacity: 1
  });
  
  const obstaclesRef = useRef<Obstacle[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const trailsRef = useRef<{x: number, y: number, life: number, stretchX: number, stretchY: number}[]>([]);
  const speedRef = useRef(INITIAL_SPEED);
  const scoreRef = useRef(0);
  const frameCountRef = useRef(0);
  const shakeRef = useRef(0);
  const bgOffsetRef = useRef(0);
  const comboRef = useRef(0);

  const theme = THEMES[currentThemeIndex];

  const createParticles = (x: number, y: number, color: string, count = 5, size = 3, type: Particle['type'] = 'spark') => {
    for (let i = 0; i < count; i++) {
      particlesRef.current.push({
        x, y, 
        vx: (Math.random() - 0.5) * (type === 'smoke' ? 3 : 15), 
        vy: (Math.random() - 0.5) * (type === 'smoke' ? 3 : 15),
        life: 1.0, color, size: Math.random() * size + 1,
        type
      });
    }
  };

  const spawnObstacle = () => {
    const score = Math.floor(scoreRef.current / 10);
    const difficulty = Math.min(1, score / 20000);
    const typeRoll = Math.random();
    let type: 'block' | 'flying' | 'spike' = 'block';
    
    if (difficulty > 0.25 && typeRoll < 0.3) type = 'flying';
    else if (difficulty > 0.5 && typeRoll < 0.45) type = 'spike';

    const h = type === 'flying' ? 30 : (type === 'spike' ? 55 : 35 + Math.random() * (45 + difficulty * 60));
    const w = type === 'spike' ? 25 : 30 + Math.random() * 30;
    const y = type === 'flying' ? CANVAS_HEIGHT - 160 - Math.random() * 80 : CANVAS_HEIGHT - h;

    obstaclesRef.current.push({
      id: Math.random().toString(),
      x: CANVAS_WIDTH + 200, y, width: w, height: h,
      color: theme.obstacle, type, cleared: false, pulse: 0
    });
  };

  const update = useCallback(() => {
    if (status !== 'PLAYING') return;

    const player = playerRef.current;
    player.dy += GRAVITY;
    player.y += player.dy;

    // Squash & Stretch Logic
    if (!player.grounded) {
      player.stretchY = 1 + Math.abs(player.dy) * 0.03;
      player.stretchX = 1 / player.stretchY;
      player.angle += 0.15;
    } else {
      player.stretchY += (1 - player.stretchY) * 0.25;
      player.stretchX += (1 - player.stretchX) * 0.25;
      player.angle *= 0.7;
    }

    if (player.y + player.height > CANVAS_HEIGHT) {
      if (!player.grounded) {
        player.stretchY = 0.5;
        player.stretchX = 1.6;
        shakeRef.current = 5;
        createParticles(player.x + 18, CANVAS_HEIGHT, theme.primary, 6, 3, 'smoke');
      }
      player.y = CANVAS_HEIGHT - player.height;
      player.dy = 0;
      player.grounded = true;
    } else {
      player.grounded = false;
    }

    // Trails & Speed Lines
    trailsRef.current.push({ x: player.x, y: player.y, life: 1.0, stretchX: player.stretchX, stretchY: player.stretchY });
    if (trailsRef.current.length > 12) trailsRef.current.shift();
    trailsRef.current.forEach(t => t.life -= 0.1);

    if (speedRef.current > 10 && Math.random() > 0.7) {
      particlesRef.current.push({
        x: CANVAS_WIDTH, y: Math.random() * CANVAS_HEIGHT,
        vx: -speedRef.current * 2, vy: 0,
        life: 1.0, color: 'rgba(255,255,255,0.1)', size: 40, type: 'speedLine'
      });
    }

    // Engine Data
    speedRef.current += SPEED_INCREMENT + (scoreRef.current / 10000000);
    if (speedRef.current > MAX_SPEED) speedRef.current = MAX_SPEED;
    onSpeedUpdate(speedRef.current);

    scoreRef.current += 1.5;
    if (Math.floor(scoreRef.current / 10) % 10 === 0) onScoreUpdate(Math.floor(scoreRef.current / 10));

    bgOffsetRef.current = (bgOffsetRef.current + speedRef.current * 1.2) % 100;

    // Particles
    particlesRef.current.forEach((p, i) => {
      p.x += p.vx; p.y += p.vy; 
      p.life -= p.type === 'smoke' ? 0.04 : 0.02;
      if (p.life <= 0) particlesRef.current.splice(i, 1);
    });

    frameCountRef.current++;
    const spawnRate = Math.max(15, 80 - (speedRef.current * 4) - (scoreRef.current / 1200));
    if (frameCountRef.current % Math.floor(spawnRate) === 0) spawnObstacle();

    // Obstacles
    obstaclesRef.current.forEach((obs, i) => {
      obs.x -= speedRef.current;
      obs.pulse += 0.1;

      // Tight & Optimized Collision
      if (
        player.x + 6 < obs.x + obs.width &&
        player.x + player.width - 6 > obs.x &&
        player.y + 6 < obs.y + obs.height &&
        player.y + player.height - 6 > obs.y
      ) {
        shakeRef.current = 25;
        createParticles(player.x + 18, player.y + 18, '#ffffff', 30, 8, 'spark');
        onGameOver(Math.floor(scoreRef.current / 10));
      }

      // Near Miss (25px buffer)
      const buffer = 30;
      if (!obs.cleared && 
          player.x < obs.x + obs.width + buffer &&
          player.x + player.width > obs.x - buffer &&
          player.y < obs.y + obs.height + buffer &&
          player.y + player.height > obs.y - buffer) {
        onEvent('nearMiss');
        shakeRef.current = 6;
        comboRef.current++;
      }

      if (!obs.cleared && obs.x + obs.width < player.x) {
        obs.cleared = true;
        onEvent('streak');
      }

      if (obs.x + obs.width < -200) obstaclesRef.current.splice(i, 1);
    });

    if (shakeRef.current > 0) shakeRef.current -= 1.5;
  }, [status, onGameOver, onScoreUpdate, onSpeedUpdate, onEvent, theme]);

  const draw = useCallback((ctx: CanvasRenderingContext2D) => {
    ctx.save();
    
    // Camera Shake & Glitch Simulation
    if (shakeRef.current > 0) {
      const s = shakeRef.current;
      ctx.translate(Math.random() * s - s/2, Math.random() * s - s/2);
      if (s > 10) { // Glitch chromatic effect
         ctx.globalCompositeOperation = 'screen';
         ctx.fillStyle = 'rgba(255,0,0,0.1)';
         ctx.fillRect(Math.random()*10, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      }
    }
    
    ctx.fillStyle = theme.background;
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Parallax Grid
    ctx.strokeStyle = `${theme.primary}15`;
    ctx.lineWidth = 2;
    const gridSpacing = 80;
    for (let x = -bgOffsetRef.current; x < CANVAS_WIDTH + gridSpacing; x += gridSpacing) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, CANVAS_HEIGHT); ctx.stroke();
    }
    for (let y = 0; y < CANVAS_HEIGHT; y += gridSpacing) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(CANVAS_WIDTH, y); ctx.stroke();
    }

    // Speed Lines
    particlesRef.current.filter(p => p.type === 'speedLine').forEach(p => {
       ctx.strokeStyle = p.color;
       ctx.lineWidth = 2;
       ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x + p.size, p.y); ctx.stroke();
    });

    // Trails
    trailsRef.current.forEach((t, idx) => {
      ctx.globalAlpha = t.life * 0.3;
      ctx.fillStyle = theme.primary;
      ctx.save();
      ctx.translate(t.x + playerRef.current.width/2, t.y + playerRef.current.height/2);
      ctx.scale(t.stretchX, t.stretchY);
      ctx.fillRect(-playerRef.current.width/2, -playerRef.current.height/2, playerRef.current.width, playerRef.current.height);
      ctx.restore();
    });
    ctx.globalAlpha = 1.0;

    // Particles
    particlesRef.current.filter(p => p.type !== 'speedLine').forEach(p => {
      ctx.globalAlpha = p.life;
      ctx.fillStyle = p.color;
      if (p.type === 'smoke') {
        ctx.beginPath(); ctx.arc(p.x, p.y, p.size * (1.5 - p.life), 0, Math.PI * 2); ctx.fill();
      } else {
        ctx.shadowBlur = 10; ctx.shadowColor = p.color;
        ctx.fillRect(p.x, p.y, p.size, p.size);
      }
    });
    ctx.globalAlpha = 1.0; ctx.shadowBlur = 0;

    // Obstacles with Bloom
    obstaclesRef.current.forEach(obs => {
      ctx.save();
      const pulseScale = 1 + Math.sin(obs.pulse) * 0.05;
      ctx.translate(obs.x + obs.width/2, obs.y + obs.height/2);
      ctx.scale(pulseScale, pulseScale);
      
      ctx.shadowBlur = 20; ctx.shadowColor = obs.color;
      ctx.fillStyle = obs.color;
      
      if (obs.type === 'spike') {
         ctx.beginPath();
         ctx.moveTo(-obs.width/2, obs.height/2);
         ctx.lineTo(0, -obs.height/2);
         ctx.lineTo(obs.width/2, obs.height/2);
         ctx.closePath(); ctx.fill();
      } else {
         ctx.fillRect(-obs.width/2, -obs.height/2, obs.width, obs.height);
      }
      
      ctx.strokeStyle = 'white'; ctx.lineWidth = 2; ctx.globalAlpha = 0.5;
      if (obs.type === 'spike') ctx.stroke(); else ctx.strokeRect(-obs.width/2, -obs.height/2, obs.width, obs.height);
      ctx.restore();
    });

    // Player Core
    const p = playerRef.current;
    ctx.save();
    ctx.translate(p.x + p.width/2, p.y + p.height/2);
    ctx.rotate(p.angle);
    ctx.scale(p.stretchX, p.stretchY);
    
    ctx.shadowBlur = 35; ctx.shadowColor = theme.primary;
    ctx.fillStyle = theme.primary;
    ctx.fillRect(-p.width/2, -p.height/2, p.width, p.height);
    
    // Detail
    ctx.strokeStyle = 'white'; ctx.lineWidth = 3;
    ctx.strokeRect(-p.width/2 + 6, -p.height/2 + 6, p.width - 12, p.height - 12);
    
    ctx.fillStyle = 'white';
    ctx.fillRect(p.width/4, -p.height/4, 8, 8);
    ctx.restore();

    ctx.restore();
  }, [theme]);

  const loop = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    update();
    draw(ctx);
    requestRef.current = requestAnimationFrame(loop);
  }, [update, draw]);

  useEffect(() => {
    if (status === 'START') {
      obstaclesRef.current = [];
      particlesRef.current = [];
      trailsRef.current = [];
      speedRef.current = INITIAL_SPEED;
      scoreRef.current = 0;
      frameCountRef.current = 0;
      playerRef.current.y = CANVAS_HEIGHT - 60;
    }
    requestRef.current = requestAnimationFrame(loop);
    return () => { if (requestRef.current) cancelAnimationFrame(requestRef.current); };
  }, [status, loop]);

  return (
    <div className="relative border-y-8 border-slate-900 overflow-hidden shadow-[0_0_100px_rgba(0,0,0,0.8)] bg-black rounded-[2rem] group scanline-effect transition-all duration-500">
      <canvas 
        ref={canvasRef} 
        width={CANVAS_WIDTH} 
        height={CANVAS_HEIGHT} 
        className="w-full h-auto cursor-pointer select-none" 
        onClick={() => {
          const p = playerRef.current;
          if (p.grounded && status === 'PLAYING') { 
            p.dy = p.jumpForce; 
            p.stretchY = 1.8; p.stretchX = 0.6;
            createParticles(p.x + 18, p.y + 36, theme.primary, 12, 5, 'spark'); 
          }
        }} 
      />
      {/* Dynamic Feedback Overlays */}
      <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
         {shakeRef.current > 5 && <div className="w-full h-full border-[20px] border-white/5 animate-pulse"></div>}
      </div>
    </div>
  );
};

export default GameCanvas;
