
import React from 'react';
import { GameState } from '../types';

interface HUDProps {
  gameState: GameState;
}

const HUD: React.FC<HUDProps> = ({ gameState }) => {
  return (
    <div className="flex justify-between items-end w-full px-2 md:px-6 font-orbitron">
      <div className="space-y-0 md:space-y-1">
        <span className="text-[8px] md:text-[10px] text-slate-500 uppercase tracking-widest font-black">Sync Distance</span>
        <div className="text-2xl md:text-5xl font-black text-white tabular-nums drop-shadow-[0_0_10px_rgba(255,255,255,0.3)]">
          {gameState.score}<span className="text-[10px] md:text-sm text-sky-500 ml-1 font-bold italic">LY</span>
        </div>
      </div>
      
      <div className="hidden sm:flex flex-col items-center">
        <div className="flex items-center gap-1 md:gap-4">
          <div className="flex flex-col items-center border-x border-white/5 px-4 md:px-8">
            <span className="text-[8px] md:text-[10px] text-slate-500 uppercase font-black">Velocity</span>
            <span className="text-lg md:text-2xl text-emerald-400 font-black">{(gameState.speed * 10).toFixed(0)}</span>
          </div>
          <div className="flex flex-col items-center px-4 md:px-8">
            <span className="text-[8px] md:text-[10px] text-slate-500 uppercase font-black">Dodge+</span>
            <span className="text-lg md:text-2xl text-fuchsia-500 font-black">{gameState.nearMisses}</span>
          </div>
        </div>
      </div>

      <div className="space-y-0 md:space-y-1 text-right">
        <span className="text-[8px] md:text-[10px] text-slate-500 uppercase tracking-widest font-black">Record</span>
        <div className="text-xl md:text-3xl font-black text-slate-500 tabular-nums">
          {gameState.highScore}<span className="text-[8px] md:text-xs ml-1 font-bold">LY</span>
        </div>
      </div>
    </div>
  );
};

export default HUD;
