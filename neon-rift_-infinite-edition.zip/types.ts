
export type GameStatus = 'START' | 'PLAYING' | 'PAUSED' | 'GAMEOVER';

export interface GameState {
  score: number;
  highScore: number;
  status: GameStatus;
  speed: number;
  level: number;
  nearMisses: number;
  jumpStreak: number;
  combo: number;
}

export interface Player {
  x: number;
  y: number;
  width: number;
  height: number;
  dy: number;
  jumpForce: number;
  grounded: boolean;
  angle: number;
  stretchX: number;
  stretchY: number;
  opacity: number;
}

export interface Obstacle {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  color: string;
  type: 'block' | 'flying' | 'spike';
  cleared: boolean;
  pulse: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  color: string;
  size: number;
  type: 'spark' | 'smoke' | 'speedLine';
}

export interface Commentary {
  text: string;
  mood: 'neutral' | 'impressed' | 'mocking' | 'encouraging' | 'panicked';
}
