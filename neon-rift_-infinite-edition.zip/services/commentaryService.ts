
import { Commentary } from "../types";

const PHRASES = {
  neutral: ["System initialized.", "Monitoring pulse.", "Rift stability: 99%.", "Trajectory locked.", "Sync established."],
  encouraging: ["Good flow, Operator.", "Solid rhythmic inputs.", "Velocity within limits.", "Optimal dodging.", "Stay sharp."],
  impressed: ["GODLIKE REFLEXES!", "Absolute unit.", "Total rift dominance!", "You're seeing the code!", "Synaptic overlap reached!"],
  panicked: ["DANGER: Speed overload!", "Rift integrity critical!", "Pull back!", "Physics engine failing!", "VELOCITY WARNING!"],
  mocking: ["Connection lost.", "Operator error.", "Predictable collision.", "Try aiming next time.", "Rift: 1, Human: 0."],
  nearMiss: ["Calculated.", "Atomic-level dodge.", "Frame-perfect!", "Close call.", "Risk rewarded."]
};

export function getLocalCommentary(
  event: 'start' | 'gameover' | 'nearMiss' | 'streak' | 'speed' | 'milestone',
  value?: number
): Commentary {
  let pool: string[] = PHRASES.neutral;
  let mood: Commentary['mood'] = 'neutral';

  switch (event) {
    case 'start':
      pool = PHRASES.neutral;
      break;
    case 'gameover':
      pool = PHRASES.mocking;
      mood = 'mocking';
      break;
    case 'nearMiss':
      pool = PHRASES.nearMiss;
      mood = 'encouraging';
      break;
    case 'streak':
      pool = PHRASES.impressed;
      mood = 'impressed';
      break;
    case 'speed':
      pool = PHRASES.panicked;
      mood = 'panicked';
      break;
    case 'milestone':
      pool = PHRASES.impressed;
      mood = 'impressed';
      break;
  }

  const text = pool[Math.floor(Math.random() * pool.length)];
  return { text, mood };
}
