
import { GoogleGenAI } from "@google/genai";
import { Commentary } from "../types";

// Initialize the Gemini API client with the environment variable API_KEY
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Generates AI-powered commentary for the game using Gemini.
 * Uses gemini-3-flash-preview for fast, reactive text generation.
 */
export async function getAICommentary(
  score: number, 
  speed: number, 
  isGameOver: boolean,
  context?: { nearMisses: number; jumpStreak: number }
): Promise<Commentary> {
  const model = 'gemini-3-flash-preview';
  
  let dynamicContext = "";
  if (context) {
    if (context.nearMisses > 0) dynamicContext += ` They just had ${context.nearMisses} near misses!`;
    if (context.jumpStreak > 5) dynamicContext += ` They are on a ${context.jumpStreak} jump streak!`;
  }

  const prompt = isGameOver 
    ? `The player just crashed with a score of ${score}. Give a short, witty, or slightly mocking comment. Keep it under 12 words.`
    : `Score: ${score}, Speed: ${speed.toFixed(1)}x.${dynamicContext} Provide a short reactive comment (under 10 words). Use tech/cyberpunk slang.`;

  try {
    // Generate content using the model name and prompt directly as per guidelines
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        systemInstruction: "You are 'Rift-OS', a sarcastic but impressed AI watching a human play a dangerous neon runner. Use short, punchy, futuristic sentences.",
        temperature: 0.9,
        maxOutputTokens: 40,
        // Set thinkingBudget to 0 to minimize latency for game reactions
        thinkingConfig: { thinkingBudget: 0 },
      }
    });

    // Access the text property directly (not a method)
    const text = response.text || "Scanning vitals...";
    
    // Fixed: Use 'Commentary' instead of 'AICommentary'
    let mood: Commentary['mood'] = 'neutral';
    if (context && (context.nearMisses > 2 || context.jumpStreak > 8)) mood = 'impressed';
    if (speed > 10) mood = 'panicked';
    if (isGameOver) mood = 'mocking';

    return { text, mood };
  } catch (error) {
    // Basic error handling for API failures
    console.error("AI Commentary failed:", error);
    return { text: "Data stream interrupted...", mood: 'neutral' };
  }
}
