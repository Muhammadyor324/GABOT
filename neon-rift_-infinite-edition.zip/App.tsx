
import React, { useState, useCallback, useRef, useEffect } from 'react';
import GameCanvas from './components/GameCanvas';
import HUD from './components/HUD';
import { GameState, Commentary, GameStatus } from './types';
import { getLocalCommentary } from './services/commentaryService';
import { INITIAL_SPEED } from './constants';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>({
    score: 0,
    highScore: Number(localStorage.getItem('neon_high_score')) || 0,
    status: 'START',
    speed: INITIAL_SPEED,
    level: 1,
    nearMisses: 0,
    jumpStreak: 0,
    combo: 0
  });

  const [aiMessage, setAiMessage] = useState<Commentary>({
    text: "Rift-OS v4.0 [LEGACY]. Ready for sync.",
    mood: 'neutral'
  });

  const streakRef = useRef(0);
  const nearMissRef = useRef(0);

  const handleGameOver = useCallback((finalScore: number) => {
    setGameState(prev => {
      const newHighScore = Math.max(prev.highScore, finalScore);
      localStorage.setItem('neon_high_score', newHighScore.toString());
      return { ...prev, status: 'GAMEOVER', highScore: newHighScore };
    });
    setAiMessage(getLocalCommentary('gameover'));
  }, []);

  const handleScoreUpdate = useCallback((score: number) => {
    setGameState(prev => ({ ...prev, score, level: Math.floor(score / 2000) + 1 }));
    if (score > 0 && score % 2500 === 0) {
       setAiMessage(getLocalCommentary('milestone', score));
    }
  }, []);

  const handleSpeedUpdate = useCallback((speed: number) => {
    setGameState(prev => ({ ...prev, speed }));
  }, []);

  const handleEvent = useCallback((type: 'nearMiss' | 'streak' | 'milestone') => {
    if (type === 'nearMiss') {
      nearMissRef.current++;
      setGameState(prev => ({ ...prev, nearMisses: prev.nearMisses + 1, combo: prev.combo + 1 }));
      if (nearMissRef.current % 4 === 0) setAiMessage(getLocalCommentary('nearMiss'));
    } else if (type === 'streak') {
      streakRef.current++;
      setGameState(prev => ({ ...prev, jumpStreak: streakRef.current }));
      if (streakRef.current % 15 === 0) setAiMessage(getLocalCommentary('streak', streakRef.current));
    }
  }, []);

  const startGame = () => {
    setGameState(prev => ({ ...prev, status: 'PLAYING', score: 0, nearMisses: 0, jumpStreak: 0, combo: 0 }));
    streakRef.current = 0;
    nearMissRef.current = 0;
    setAiMessage(getLocalCommentary('start'));
  };

  const returnToMenu = () => {
    setGameState(prev => ({ ...prev, status: 'START' }));
  };

  const togglePause = () => {
    setGameState(prev => ({ 
      ...prev, 
      status: prev.status === 'PLAYING' ? 'PAUSED' : 'PLAYING' 
    }));
  };

  const moodStyles = {
    neutral: 'text-sky-400 border-sky-500/20 bg-sky-500/5',
    impressed: 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10 shadow-[0_0_30px_rgba(16,185,129,0.2)]',
    mocking: 'text-rose-400 border-rose-500/30 bg-rose-500/5',
    encouraging: 'text-fuchsia-400 border-fuchsia-500/20 bg-fuchsia-500/5',
    panicked: 'text-amber-400 border-amber-500/40 bg-amber-500/15 animate-pulse'
  };

  return (
    <div className="fixed inset-0 bg-[#020617] text-slate-100 flex flex-col font-sans overflow-hidden selection:bg-sky-500/30">
      
      {/* Premium Background FX */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
         <div className="absolute -top-[20%] -left-[10%] w-[60%] h-[60%] bg-sky-500/10 rounded-full blur-[150px] animate-pulse"></div>
         <div className="absolute -bottom-[20%] -right-[10%] w-[60%] h-[60%] bg-fuchsia-500/10 rounded-full blur-[150px] animate-pulse"></div>
         <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-[0.03]"></div>
      </div>

      <div className="relative z-10 flex flex-col h-full max-w-7xl mx-auto w-full p-4 md:p-8 space-y-4">
        
        {/* Header Section */}
        <header className="flex justify-between items-center shrink-0">
          <div className="group cursor-default">
            <h1 className="text-3xl md:text-6xl font-orbitron font-black tracking-tighter italic text-transparent bg-clip-text bg-gradient-to-br from-white via-sky-400 to-fuchsia-600 drop-shadow-2xl">
              NEON RIFT <span className="text-xs not-italic opacity-30 font-bold tracking-widest ml-2">ULTRA</span>
            </h1>
            <div className="flex items-center gap-2 mt-1">
               <div className="h-1 w-12 bg-gradient-to-r from-sky-500 to-transparent rounded-full"></div>
               <p className="text-[8px] md:text-[10px] uppercase tracking-[0.6em] text-slate-500 font-black">Neural Interface established</p>
            </div>
          </div>
          
          <div className="flex gap-3">
            {gameState.status === 'PLAYING' && (
              <button onClick={togglePause} className="glass group flex items-center gap-2 px-6 py-3 rounded-2xl active:scale-90 transition-all border-white/10 hover:border-white/30">
                <div className="w-2 h-2 rounded-full bg-white animate-pulse"></div>
                <span className="font-orbitron text-[10px] font-black tracking-[0.2em]">PAUSE</span>
              </button>
            )}
          </div>
        </header>

        <main className="flex-1 grid grid-cols-1 lg:grid-cols-4 gap-4 md:gap-8 overflow-hidden min-h-0">
          
          {/* Game Viewport Area */}
          <div className="lg:col-span-3 flex flex-col space-y-4 min-h-0">
            <HUD gameState={gameState} />
            
            <div className="relative flex-1 min-h-0">
              <GameCanvas 
                status={gameState.status} 
                onGameOver={handleGameOver}
                onScoreUpdate={handleScoreUpdate}
                onSpeedUpdate={handleSpeedUpdate}
                onEvent={handleEvent}
              />

              {/* Enhanced Overlays */}
              {gameState.status === 'START' && (
                <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/70 backdrop-blur-3xl rounded-[2rem] p-8 border border-white/5 animate-in fade-in zoom-in duration-500">
                  <div className="text-center space-y-8 max-w-md">
                    <div className="relative">
                       <div className="absolute inset-0 bg-sky-500 blur-3xl opacity-20 animate-pulse"></div>
                       <h2 className="relative text-5xl md:text-7xl font-orbitron font-black text-white tracking-tighter italic">READY?</h2>
                    </div>
                    <p className="text-slate-400 text-sm md:text-base font-medium leading-relaxed">
                      Harmonize with the rift. Surpass the speed of light. Survial is the only metric that matters.
                    </p>
                    
                    <button 
                      onClick={startGame} 
                      className="group relative w-full py-6 bg-white text-black rounded-3xl overflow-hidden transition-all hover:scale-[1.03] active:scale-95 shadow-[0_30px_60px_-15px_rgba(255,255,255,0.2)]"
                    >
                      <div className="absolute inset-0 bg-gradient-to-r from-sky-400 to-fuchsia-500 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                      <span className="relative font-orbitron font-black tracking-[0.3em] text-xl group-hover:text-white transition-colors">LINK START</span>
                    </button>
                    
                    <div className="grid grid-cols-3 gap-4 pt-6 opacity-40">
                       <div className="text-center"><span className="block text-white font-black text-xs">JUMP</span><span className="text-[8px] uppercase font-bold">Space / Tap</span></div>
                       <div className="text-center"><span className="block text-white font-black text-xs">DODGE</span><span className="text-[8px] uppercase font-bold">Timing</span></div>
                       <div className="text-center"><span className="block text-white font-black text-xs">SYNC</span><span className="text-[8px] uppercase font-bold">Persistence</span></div>
                    </div>
                  </div>
                </div>
              )}

              {gameState.status === 'PAUSED' && (
                <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/50 backdrop-blur-2xl rounded-[2rem] animate-in fade-in duration-300">
                   <h2 className="text-5xl font-orbitron font-black text-white mb-12 tracking-tighter italic">SUSPENDED</h2>
                   <div className="flex gap-4">
                      <button onClick={togglePause} className="px-12 py-6 bg-sky-500 text-white font-orbitron font-black rounded-3xl shadow-2xl active:scale-90 transition-transform tracking-widest">RESUME</button>
                      <button onClick={returnToMenu} className="px-8 py-6 glass text-white font-orbitron font-black rounded-3xl active:scale-90 transition-transform text-xs">EXIT</button>
                   </div>
                </div>
              )}

              {gameState.status === 'GAMEOVER' && (
                <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-rose-950/80 backdrop-blur-3xl rounded-[2rem] p-8 border border-rose-500/20 animate-in zoom-in-95 duration-300">
                  <div className="text-center space-y-10 w-full max-w-lg">
                    <h2 className="text-5xl md:text-8xl font-orbitron font-black text-rose-500 italic tracking-tighter drop-shadow-[0_0_30px_rgba(244,63,94,0.4)]">CRITICAL ERROR</h2>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="glass p-6 rounded-[2rem] border-white/5">
                        <p className="text-slate-500 uppercase text-[10px] font-black mb-2 tracking-widest">SYNC DISTANCE</p>
                        <p className="text-4xl md:text-6xl text-white font-orbitron font-black">{gameState.score}</p>
                      </div>
                      <div className="glass p-6 rounded-[2rem] border-emerald-500/10">
                        <p className="text-emerald-500/50 uppercase text-[10px] font-black mb-2 tracking-widest">BEST RECORD</p>
                        <p className="text-4xl md:text-6xl text-emerald-400 font-orbitron font-black">{gameState.highScore}</p>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
                      <button onClick={startGame} className="flex-1 py-6 bg-white text-slate-900 font-orbitron font-black rounded-[2rem] shadow-2xl active:scale-95 transition-all text-lg tracking-widest hover:bg-sky-400 hover:text-white">REBOOT_LINK</button>
                      <button onClick={returnToMenu} className="flex-1 py-6 glass text-white font-orbitron font-black rounded-[2rem] active:scale-95 transition-all text-sm tracking-widest">MAIN_TERMINAL</button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* AI Terminal Sidebar */}
          <aside className="lg:col-span-1 flex flex-col space-y-4 overflow-hidden">
            <div className="glass rounded-[2rem] p-6 flex flex-col h-full border-white/5">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                   <div className="h-2 w-2 rounded-full bg-emerald-500 animate-ping"></div>
                   <span className="text-[10px] font-orbitron text-slate-400 uppercase tracking-widest font-black italic">RIFT-OS 4.0</span>
                </div>
                <span className="text-[8px] font-black text-slate-600">STABLE_LINK</span>
              </div>

              <div className={`flex-1 flex items-center justify-center p-8 rounded-3xl border transition-all duration-1000 ${moodStyles[aiMessage.mood]}`}>
                <p className="text-center font-bold italic leading-relaxed text-base md:text-xl drop-shadow-sm">
                   "{aiMessage.text}"
                </p>
              </div>

              <div className="mt-8 space-y-6">
                <div className="space-y-3">
                  <div className="flex justify-between text-[10px] uppercase font-black text-slate-500 tracking-tighter">
                    <span>COMBO MULTIPLIER</span>
                    <span className="text-fuchsia-500 font-orbitron font-black">x{(1 + gameState.combo * 0.1).toFixed(1)}</span>
                  </div>
                  <div className="h-2 bg-black/40 rounded-full overflow-hidden border border-white/5">
                    <div 
                      className="h-full bg-gradient-to-r from-sky-500 via-fuchsia-500 to-white transition-all duration-500 shadow-[0_0_15px_rgba(255,255,255,0.3)]" 
                      style={{ width: `${Math.min(100, gameState.combo * 8)}%` }} 
                    />
                  </div>
                </div>

                <div className="pt-6 border-t border-white/5 grid grid-cols-2 gap-4">
                   <div className="text-center">
                     <p className="text-[8px] font-black text-slate-600 mb-1 uppercase">LEVEL</p>
                     <p className="text-xl font-orbitron font-black text-white italic">{gameState.level}</p>
                   </div>
                   <div className="text-center">
                     <p className="text-[8px] font-black text-slate-600 mb-1 uppercase">SYNC_RATE</p>
                     <p className="text-xl font-orbitron font-black text-sky-400">{(100 - (gameState.speed * 3)).toFixed(0)}%</p>
                   </div>
                </div>
              </div>
            </div>
          </aside>
        </main>

        <footer className="text-center text-[9px] text-slate-700 uppercase tracking-[1em] font-black py-4 shrink-0">
          Neural Interface Protocol // Established 2024 // End of Signal
        </footer>
      </div>
    </div>
  );
};

export default App;
