
export const CANVAS_WIDTH = 1000;
export const CANVAS_HEIGHT = 500;
export const GRAVITY = 0.7;
export const INITIAL_SPEED = 6;
export const SPEED_INCREMENT = 0.0008;
export const MAX_SPEED = 15;

export const THEMES = [
  {
    name: 'Neon Night',
    primary: '#22d3ee', // Cyan
    secondary: '#f472b6', // Pink
    background: '#020617',
    obstacle: '#f43f5e', // Rose
    accent: '#818cf8' // Indigo
  },
  {
    name: 'Toxic Waste',
    primary: '#4ade80', // Green
    secondary: '#facc15', // Yellow
    background: '#052e16',
    obstacle: '#ea580c', // Orange
    accent: '#bef264'
  },
  {
    name: 'Hyper Drive',
    primary: '#a78bfa', // Violet
    secondary: '#2dd4bf', // Teal
    background: '#1e1b4b',
    obstacle: '#fbbf24', // Amber
    accent: '#e879f9'
  }
];
